zip -r tokopinireviews.zip tokopinireviews
