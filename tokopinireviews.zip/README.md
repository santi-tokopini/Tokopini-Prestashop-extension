# TokoPini Prestashop Plugin

## Installation

- Download plugin from the plugin repository to local directory as zip.
- Unzip locally downloaded file
- Create zip archive of TokoPini directory or run `bash build.sh`
- Go to the PrestaShop administration page [http://your-prestashop-url/admin].
- Go to Modules > Modules.
- Click add new module and select the archive you've just created
- Activate and configure the plugin
